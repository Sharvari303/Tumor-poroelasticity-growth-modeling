#!/bin/bash
#SBATCH -N 1
#SBATCH -p RM-shared
#####################################################
#SBATCH --tasks-per-node=64
#SBATCH -t 1:00:00
#SBATCH --mail-type=END,FAIL
#SBATCH --mail-user=sskemkar@seas.upenn.edu
###SBATCH -C "[ib1|ib2|ib3|ib4]"
#SBATCH -o output.dat
#SBATCH -e stderr_file
#####################################################

#echo "Current directory during script execution: $(pwd)"
cd $(pwd)
#echo "Current directory after cd script execution: $(pwd)"

echo $(pwd)>job_details.dat
echo "starting time: ">>job_details.dat
date >>job_details.dat
module load CP2K/8.1-gcc10.2.0-openmpi4.0.5
jobid=`echo $SLURM_JOBID | cut -f1 -d '.'` 
rundir=/scratch/job-$jobid 
echo "name of rundir is $rundir" >>job_details.dat
###mkdir -pv $rundir
###cp -r ./* $rundir
###cd $rundir
./project ./config/PhysiCell_settings.xml
#####export DYLD_LIBRARY_PATH=$DYLD_LIBRARY_PATH:./addons/libRoadrunner/roadrunner/lib
####./ode_energy
###mv * $SLURM_SUBMIT_DIR
###cd /tmp
###rmdir $rundir

