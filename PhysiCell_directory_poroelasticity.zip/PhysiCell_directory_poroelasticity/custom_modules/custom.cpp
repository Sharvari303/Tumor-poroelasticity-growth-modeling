/*
###############################################################################
# If you use PhysiCell in your project, please cite PhysiCell and the version #
# number, such as below:                                                      #
#                                                                             #
# We implemented and solved the model using PhysiCell (Version x.y.z) [1].    #
#                                                                             #
# [1] A Ghaffarizadeh, R Heiland, SH Friedman, SM Mumenthaler, and P Macklin, #
#     PhysiCell: an Open Source Physics-Based Cell Simulator for Multicellu-  #
#     lar Systems, PLoS Comput. Biol. 14(2): e1005991, 2018                   #
#     DOI: 10.1371/journal.pcbi.1005991                                       #
#                                                                             #
# See VERSION.txt or call get_PhysiCell_version() to get the current version  #
#     x.y.z. Call display_citations() to get detailed information on all cite-#
#     able software used in your PhysiCell application.                       #
#                                                                             #
# Because PhysiCell extensively uses BioFVM, we suggest you also cite BioFVM  #
#     as below:                                                               #
#                                                                             #
# We implemented and solved the model using PhysiCell (Version x.y.z) [1],    #
# with BioFVM [2] to solve the transport equations.                           #
#                                                                             #
# [1] A Ghaffarizadeh, R Heiland, SH Friedman, SM Mumenthaler, and P Macklin, #
#     PhysiCell: an Open Source Physics-Based Cell Simulator for Multicellu-  #
#     lar Systems, PLoS Comput. Biol. 14(2): e1005991, 2018                   #
#     DOI: 10.1371/journal.pcbi.1005991                                       #
#                                                                             #
# [2] A Ghaffarizadeh, SH Friedman, and P Macklin, BioFVM: an efficient para- #
#     llelized diffusive transport solver for 3-D biological simulations,     #
#     Bioinformatics 32(8): 1256-8, 2016. DOI: 10.1093/bioinformatics/btv730  #
#                                                                             #
###############################################################################
#                                                                             #
# BSD 3-Clause License (see https://opensource.org/licenses/BSD-3-Clause)     #
#                                                                             #
# Copyright (c) 2015-2021, Paul Macklin and the PhysiCell Project             #
# All rights reserved.                                                        #
#                                                                             #
# Redistribution and use in source and binary forms, with or without          #
# modification, are permitted provided that the following conditions are met: #
#                                                                             #
# 1. Redistributions of source code must retain the above copyright notice,   #
# this list of conditions and the following disclaimer.                       #
#                                                                             #
# 2. Redistributions in binary form must reproduce the above copyright        #
# notice, this list of conditions and the following disclaimer in the         #
# documentation and/or other materials provided with the distribution.        #
#                                                                             #
# 3. Neither the name of the copyright holder nor the names of its            #
# contributors may be used to endorse or promote products derived from this   #
# software without specific prior written permission.                         #
#                                                                             #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" #
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE   #
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE  #
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE   #
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR         #
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF        #
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS    #
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN     #
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)     #
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE  #
# POSSIBILITY OF SUCH DAMAGE.                                                 #
#                                                                             #
###############################################################################
*/

#include "./custom.h"
#include <sstream>

void create_cell_types( void )
{
	// set the random seed 
	if (parameters.ints.find_index("random_seed") != -1)
	{
		SeedRandom(parameters.ints("random_seed"));
	}
	
	/* 
	   Put any modifications to default cell definition here if you 
	   want to have "inherited" by other cell types. 
	   
	   This is a good place to set default functions. 
	*/ 
	
	initialize_default_cell_definition(); 
	cell_defaults.phenotype.secretion.sync_to_microenvironment( &microenvironment ); 
	
	cell_defaults.functions.volume_update_function = standard_volume_update_function;
	cell_defaults.functions.update_velocity = standard_update_cell_velocity;

	cell_defaults.functions.update_migration_bias = NULL; 
	cell_defaults.functions.update_phenotype = NULL; // update_cell_and_death_parameters_O2_based; 
	cell_defaults.functions.custom_cell_rule = NULL; 
	cell_defaults.functions.contact_function = NULL; 
	
	cell_defaults.functions.add_cell_basement_membrane_interactions = NULL; 
	cell_defaults.functions.calculate_distance_to_membrane = NULL; 
	
	/*
	   This parses the cell definitions in the XML config file. 
	*/
	
	initialize_cell_definitions_from_pugixml(); 

	/*
	   This builds the map of cell definitions and summarizes the setup. 
	*/
		
	build_cell_definitions_maps(); 

	/*
	   This intializes cell signal and response dictionaries 
	*/

	setup_signal_behavior_dictionaries(); 	

	/*
       Cell rule definitions 
	*/

	setup_cell_rules(); 

	/* 
	   Put any modifications to individual cell definitions here. 
	   
	   This is a good place to set custom functions. 
	*/ 
	
	cell_defaults.functions.update_phenotype = phenotype_function; 
	cell_defaults.functions.custom_cell_rule = custom_function; 
	cell_defaults.functions.contact_function = contact_function; 
	
	/*
	   This builds the map of cell definitions and summarizes the setup. 
	*/
		
	display_cell_definitions( std::cout ); 
	
	return; 
}

void setup_microenvironment( void )
{
	// set domain parameters 
	
	// put any custom code to set non-homogeneous initial conditions or 
	// extra Dirichlet nodes here. 
	
	// initialize BioFVM 
	
	initialize_microenvironment(); 	
	
	return; 
}

void setup_tissue( void )
{
	double Xmin = microenvironment.mesh.bounding_box[0]; 
	double Ymin = microenvironment.mesh.bounding_box[1]; 
	double Zmin = microenvironment.mesh.bounding_box[2]; 

	double Xmax = microenvironment.mesh.bounding_box[3]; 
	double Ymax = microenvironment.mesh.bounding_box[4]; 
	double Zmax = microenvironment.mesh.bounding_box[5]; 
	
	if( default_microenvironment_options.simulate_2D == true )
	{
		Zmin = 0.0; 
		Zmax = 0.0; 
	}
	
	double Xrange = Xmax - Xmin; 
	double Yrange = Ymax - Ymin; 
	double Zrange = Zmax - Zmin; 
	
	// create some of each type of cell 
    
        //cancer cells initialized - random spherical
	    Cell* pC = NULL;
	    double tumor_radius = parameters.doubles("tumor_radius");
        double cell_radius = cell_defaults.phenotype.geometry.radius; 
		Cell_Definition* pCD = cell_definitions_by_index[0]; //0 stands for S cancer cells
		//Cell_Definition* pCD_R = cell_definitions_by_index[1]; //1 stands for R cancer cells
        
		//creating array to store all positions generated 
		std::vector<std::vector<double>> store_positions_S;
		while (store_positions_S.size() < parameters.ints("number_of_cells") ) 
        {   //printf("store_positions=%f\n" ,store_positions);
            std::vector<double> position = {0,0,0}; 
			double theta = 2*3.14*UniformRandom();
			position[0] = tumor_radius*UniformRandom()*cos(theta); 
			position[1] = tumor_radius*UniformRandom()*sin(theta);
			position[2] = 0; 
			//printf("position[0]=%f\n" ,position[0]);
		    std::vector<double> compare_position = {0,0,0};  //temporary variable to store position of circle for comparison
			double distance = 0;
			bool overlapping = false;
			for (int j=0 ; j < store_positions_S.size() ; j++) 
			{
               compare_position = store_positions_S[j];
			   distance = distanceCalculate(compare_position[0], position[0], compare_position[1], position[1]);
               
			   if ( distance < 2.0*cell_radius ) 
			   {  //printf("distance=%f\n" ,distance);
			      //printf("2.0*cell_radius=%f\n" ,2.0*cell_radius);
                  overlapping = true;
				  break;
			   }

			}

			if (!overlapping )
			{  //printf("distance=%f\n" ,distance);
			   //printf("2.0*cell_radius=%f\n" ,2.0*cell_radius);
				pC = create_cell( *pCD ); 
			    pC->assign_position( position );
            
			    store_positions_S.push_back(position);
			}

			
		
		}
		
	
	
// load cells from your CSV file (if enabled)
	load_cells_from_pugixml();
	set_parameters_from_distributions();
		
	return; 
}

// std::vector<std::string> my_coloring_function( Cell* pCell )
// { return paint_by_number_cell_coloring(pCell); }

std::vector<std::string> growth_rate_coloring( Cell* pCell)
{
    // // 1) get the cell's current cycle‐entry rate
    // auto& cycle = pCell->phenotype.cycle;
    // double rate = cycle.data.transition_rate(0 , 0 ) ;

    // // 2) normalize (you could also load this from a XML user_parameter)
    // static double max_rate = 2e-4 ; 
    // double norm = rate / max_rate;
    // norm = std::min( 1.0, std::max( 0.0, norm) );

    // // 3) map to a red→green gradient
    // int r = (int)(255 * (1.0 - norm));
    // int g = (int)(255 * norm);
    // int b = 0;

    // std::ostringstream oss;
    // oss << "rgb(" << r << "," << g << "," << b << ")";

    // // 4) fill & outline colors
    // return { oss.str(),    // cytoplasm fill
    //          "black",      // cytoplasm outline
    //          oss.str(),    // nucleus fill (optional)
    //          "black" };    // nucleus outline

std::vector<std::string> output = paint_by_number_cell_coloring(pCell);
if (pCell->phenotype.death.dead == false)
{
   double s = get_single_behavior(pCell, "cycle entry");
   static double max_rate = 2e-4 ; 
   s = s/max_rate;
   int color = (int) round(255.0*s);
   char szColor[1024];
   sprintf(szColor, "rgb(%u,%u,%u)", color, color, 255-color);
   output[0] = szColor;
   output[2] = szColor;
   output[3]= szColor;

}
return output;
}

void phenotype_function( Cell* pCell, Phenotype& phenotype, double dt )
{ return; }

void custom_function( Cell* pCell, Phenotype& phenotype , double dt )
{ return; } 

void contact_function( Cell* pMe, Phenotype& phenoMe , Cell* pOther, Phenotype& phenoOther , double dt )
{ return; } 

void track_cell_populations(void)
{
    // Get cell definitions
    static Cell_Definition* pTEN_N = find_cell_definition("cancer_cell");
    
    // Initialize counters
    int total_cells = 0;
    int alive_pten_normal = 0;
    int dead_pten_normal = 0;
    
    Cell* pCell = NULL;
    
    // Loop through all cells
    for (int i = 0; i < (*all_cells).size(); i++)
    {
        pCell = (*all_cells)[i];
        total_cells++;
        
        // Count PTEN normal cells
        if (pCell->type == pTEN_N->type)
        {
            if (pCell->phenotype.death.dead == false)
                alive_pten_normal++;
            else
                dead_pten_normal++;
        }
    }
    
    // Get current simulation time
    double current_time = PhysiCell_globals.current_time;
    
    // Write to CSV file
    static bool first_run = true;
    std::ofstream file;
    
    if (first_run)
    {
        // Create new file with headers on first run
        file.open("cell_populations.csv");
        file << "Time,Total_Cells,Alive,Dead\n";
        first_run = false;
    }
    else
    {
        // Append to existing file
        file.open("cell_populations.csv", std::ios::app);
    }
    
    // Write data
    file << current_time << ",";
    file << total_cells << ",";
    file << alive_pten_normal << ",";
    file << dead_pten_normal << "\n";
    
    file.close();
}

double distanceCalculate(double x1, double y1, double x2, double y2)//calculates distance between centers of two circles/agents 
{
	double x = x1 - x2; //calculating number to square in next step
	double y = y1 - y2;
	double dist;

	dist = pow(x, 2) + pow(y, 2);       //calculating Euclidean distance
	dist = sqrt(dist);                  

	return dist;
}
